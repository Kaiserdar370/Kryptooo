/* kryptooo shared behavior: theme, mobile menu, consent, ads, contact form, TOC */
(() => {
'use strict';
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const store = {
  get(k){ try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v){ try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } },
};

/* ---- theme (preference remembered; first paint is set by an inline head script) ---- */
function applyTheme(t, persist){
  document.documentElement.dataset.theme = t;
  const m = $('meta[name="theme-color"]'); if (m) m.content = t === 'light' ? '#f2f5fa' : '#0a1020';
  const b = $('#themeBtn'); if (b) b.setAttribute('aria-label', t === 'light' ? 'Switch to dark theme' : 'Switch to light theme');
  if (persist) store.set('kryptooo_theme', t);
  window.dispatchEvent(new Event('kryptooo:theme'));
}
const themeBtn = $('#themeBtn');
if (themeBtn){
  applyTheme(document.documentElement.dataset.theme, false);
  themeBtn.addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark', true));
}

/* ---- mobile navigation drawer ---- */
const menuBtn = $('#menuBtn'), mnav = $('#mnav');
if (menuBtn && mnav){
  menuBtn.addEventListener('click', () => {
    const open = menuBtn.getAttribute('aria-expanded') !== 'true';
    menuBtn.setAttribute('aria-expanded', open); mnav.hidden = !open;
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !mnav.hidden){ mnav.hidden = true; menuBtn.setAttribute('aria-expanded', 'false'); menuBtn.focus(); } });
}

const yr = $('#yr'); if (yr) yr.textContent = new Date().getFullYear();

/* ---- table of contents highlight ---- */
const heads = $$('.prose h2[id]'), links = $$('.toc a');
if (heads.length && links.length && 'IntersectionObserver' in window){
  const io = new IntersectionObserver(es => es.forEach(en => {
    if (en.isIntersecting){ links.forEach(a => a.classList.toggle('on', a.getAttribute('href') === '#' + en.target.id)); }
  }), {rootMargin:'-96px 0px -70% 0px'});
  heads.forEach(h => io.observe(h));
}

/* ---- consent + advertising ----
   Ads and any non-essential cookies load only after the visitor accepts.
   For production traffic in the EEA/UK/Switzerland, use a Google-certified CMP
   (for example Google Funding Choices) instead of, or alongside, this banner. */
const R = document.documentElement.dataset.root || '';
const client = ($('meta[name="adsense-client"]') || {}).content;
let adsStarted = false;
function startAds(){
  if (adsStarted || !client) return;
  adsStarted = true;
  const s = document.createElement('script');
  s.async = true; s.crossOrigin = 'anonymous';
  s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(client);
  s.onload = () => $$('ins.adsbygoogle').forEach(() => { try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {} });
  document.head.appendChild(s);
}
function stopAdsUI(){ $$('.ad').forEach(a => a.hidden = true); }
function applyConsent(v){
  if (v === 'all'){ $$('.ad').forEach(a => a.hidden = false); startAds(); }
  else stopAdsUI();
}
function showBanner(){
  if ($('#consent')) return;
  const d = document.createElement('section');
  d.id = 'consent'; d.className = 'consent'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-labelledby', 'consentT');
  d.innerHTML = `<h2 id="consentT">Your privacy choices</h2>
    <p>We use essential storage to remember your theme and this choice. With your permission, we and our advertising partners, including Google, also use cookies to show and measure ads. You can change this at any time. See our <a href="${R}cookie-policy.html">Cookie Policy</a> and <a href="${R}privacy-policy.html">Privacy Policy</a>.</p>
    <div class="row"><button type="button" class="btn" data-c="all">Accept all</button><button type="button" class="btn ghost" data-c="essential">Essential only</button></div>`;
  d.addEventListener('click', e => {
    const b = e.target.closest('[data-c]'); if (!b) return;
    store.set('kryptooo_consent', b.dataset.c); applyConsent(b.dataset.c); d.remove();
  });
  document.body.appendChild(d);
}
const saved = store.get('kryptooo_consent');
if (saved) applyConsent(saved); else { stopAdsUI(); showBanner(); }
const reopen = $('#cookiePrefs');
if (reopen) reopen.addEventListener('click', showBanner);

/* ---- contact form: no backend on a static host, so it composes an email ---- */
const form = $('#contactForm');
if (form){
  form.addEventListener('submit', e => {
    e.preventDefault();
    const f = new FormData(form), to = form.dataset.to;
    const subject = encodeURIComponent('[' + f.get('topic') + '] ' + f.get('subject'));
    const body = encodeURIComponent(f.get('message') + '\n\n' + f.get('name') + '\n' + f.get('email'));
    location.href = 'mailto:' + to + '?subject=' + subject + '&body=' + body;
    $('#formNote').textContent = 'Your email app should open with the message ready to send. If nothing happens, write to ' + to + ' directly.';
  });
}
})();
