(() => {
'use strict';

/* ======================================================================
   1. UTILITIES
   ====================================================================== */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const REDUCE = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Seeded RNG so chart history is stable within a load but varies between loads */
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const RNG = mulberry32((Date.now() / 60000) | 0);

/** Box-Muller normal sample */
function randn(r = Math.random){let u=0,v=0;while(!u)u=r();while(!v)v=r();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}

const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MINUS = '\u2212';

const nfc = {};
const fixed = (v, d) => (nfc[d] || (nfc[d] = new Intl.NumberFormat('en-US', {minimumFractionDigits:d, maximumFractionDigits:d}))).format(v);
const fmtPrice = v => fixed(v, v >= 10 ? 2 : v >= 1 ? 3 : 4);
const fmtPct   = v => (v >= 0 ? '+' : MINUS) + fixed(Math.abs(v), 2) + '%';
function fmtCompact(v, prefix = ''){
  const a = Math.abs(v);
  for (const [n, s] of [[1e12,'T'],[1e9,'B'],[1e6,'M'],[1e3,'K']]){
    if (a >= n){ const x = a / n; return prefix + fixed(v / n, x >= 100 ? 0 : x >= 10 ? 1 : 2) + s; }
  }
  return prefix + fixed(v, 0);
}
const icon = (id, cls = '') => `<svg class="ic ${cls}" aria-hidden="true"><use href="#${id}"/></svg>`;

/* ======================================================================
   2. DATA ENGINE
   Every asset runs its own random walk with momentum and mean reversion,
   ticking at a random 1–3 s interval. Charts get Brownian-bridge history.
   ====================================================================== */

// symbol, name, sector, price, shares (billions), avg volume (millions), beta
const STOCK_DEF = [
  ['AAPL','Apple','Technology',242.10,14.9,52,1.0],
  ['MSFT','Microsoft','Technology',468.30,7.43,21,.9],
  ['NVDA','NVIDIA','Technology',186.40,24.3,190,1.7],
  ['AVGO','Broadcom','Technology',346.90,4.7,19,1.4],
  ['GOOGL','Alphabet','Communication',251.80,12.1,28,1.1],
  ['META','Meta Platforms','Communication',712.50,2.52,11,1.3],
  ['NFLX','Netflix','Communication',112.30,4.25,14,1.2],
  ['AMZN','Amazon','Consumer',228.70,10.7,38,1.2],
  ['TSLA','Tesla','Consumer',438.20,3.22,85,1.9],
  ['WMT','Walmart','Consumer',103.50,8.0,18,.6],
  ['JPM','JPMorgan Chase','Financials',301.40,2.75,8,.9],
  ['V','Visa','Financials',342.10,1.93,6,.8],
  ['LLY','Eli Lilly','Health care',781.00,.9,3.2,.9],
  ['XOM','Exxon Mobil','Energy',112.60,4.3,15,.9],
  ['CAT','Caterpillar','Industrials',512.40,.47,2.6,1.1],
];
// symbol, name, category, price, circulating supply (billions), 24h volume (USD billions), volatility factor
const CRYPTO_DEF = [
  ['BTC','Bitcoin','Store of value',104200,.0199,38,1],
  ['ETH','Ethereum','Smart contracts',3890,.1207,18,1.3],
  ['XRP','XRP','Payments',2.62,59,3.8,1.5],
  ['BNB','BNB','Exchange',742,.145,2,1.1],
  ['SOL','Solana','Smart contracts',218,.48,4.5,1.6],
  ['DOGE','Dogecoin','Meme',.341,150,2.4,1.9],
  ['ADA','Cardano','Smart contracts',.89,36,1,1.6],
  ['TRX','TRON','Payments',.274,86,.9,1],
  ['AVAX','Avalanche','Smart contracts',38.4,.42,.6,1.7],
  ['LINK','Chainlink','Oracles',21.8,.65,.7,1.6],
  ['DOT','Polkadot','Smart contracts',6.9,1.5,.3,1.6],
  ['LTC','Litecoin','Payments',118,.076,.5,1.3],
];
// symbol, name, short label, descriptor, level, tick sigma, daily vol
const INDEX_DEF = [
  ['SPX','S&P 500','S&P 500','US large cap',6842.35,.00011,.006],
  ['IXIC','Nasdaq Composite','Nasdaq','US tech-heavy',23310.82,.00015,.008],
  ['DJI','Dow Jones Industrial','Dow','US blue chip',47215.60,.0001,.005],
];

const A = {};        // symbol → asset
const LIST = [];     // assets in insertion order

/** Brownian bridge from start to end; keeps both endpoints exact */
function bridge(n, start, end, vol){
  const w = [0];
  for (let i = 1; i < n; i++) w.push(w[i-1] + randn(RNG) * vol);
  const wl = w[n-1], out = [];
  for (let i = 0; i < n; i++){
    const t = i / (n - 1);
    out.push((start + (end - start) * t) * Math.exp(w[i] - t * wl));
  }
  return out;
}

function buildSeries(a){
  const dv = a.dayVol, p = a.price;
  a.d1 = bridge(97,  a.open, p, dv / Math.sqrt(97));
  const wk = p * Math.exp(-randn(RNG) * dv * 2.0 - dv * .3);
  const mo = p * Math.exp(-randn(RNG) * dv * 3.6 - dv * .8);
  const yr = p * Math.exp(-randn(RNG) * dv * 9   - dv * 4);
  a.w1 = bridge(113, wk, p, dv * 2.2 / Math.sqrt(113));
  a.m1 = bridge(121, mo, p, dv * 3.6 / Math.sqrt(121));
  a.y1 = bridge(253, yr, p, dv * 7   / Math.sqrt(253));
}

function makeAsset(o){
  const a = Object.assign({dir:0, mom:0, nextAt:performance.now() + Math.random() * 2000, high:0, low:0}, o);
  a.anchor = a.price;
  a.high = Math.max(a.price, a.open) * (1 + Math.random() * .004);
  a.low  = Math.min(a.price, a.open) * (1 - Math.random() * .004);
  buildSeries(a);
  A[a.sym] = a; LIST.push(a);
  return a;
}

function buildAssets(){
  STOCK_DEF.forEach(([sym,name,group,price,sh,avg,beta]) => {
    const p0 = clamp(randn() * .013 * Math.sqrt(beta), -.05, .05);
    makeAsset({sym,name,short:sym,type:'stock',group,price:price,open:price/(1+p0),shares:sh*1e9,avgVol:avg*1e6,
      vol:avg*1e6*(.55+Math.random()*.3),sigma:.00028*beta,k:.0008,dayVol:.011*beta,desc:group});
  });
  CRYPTO_DEF.forEach(([sym,name,group,price,sup,vol,vf]) => {
    const p0 = clamp(randn() * .026, -.08, .08);
    makeAsset({sym,name,short:sym,type:'crypto',group,price:price,open:price/(1+p0),shares:sup*1e9,avgVol:vol*1e9,
      vol:vol*1e9*(.9+Math.random()*.2),sigma:.00055*vf,k:.0006,dayVol:.026*vf,desc:group});
  });
  INDEX_DEF.forEach(([sym,name,short,desc,lvl,sg,dv]) => {
    const p0 = clamp(randn() * .005, -.015, .015);
    makeAsset({sym,name,short,type:'index',group:'Index',price:lvl,open:lvl/(1+p0),shares:0,avgVol:0,vol:0,sigma:sg,k:.002,dayVol:dv,desc});
  });
  // aggregate: total crypto market cap (follows the sum of the twelve coins)
  const cs = LIST.filter(a => a.type === 'crypto');
  const cap  = cs.reduce((s,a) => s + a.price * a.shares, 0);
  const capO = cs.reduce((s,a) => s + a.open  * a.shares, 0);
  makeAsset({sym:'TMC',name:'Crypto market cap',short:'Crypto cap',type:'index',group:'Index',agg:true,price:cap,open:capO,
    shares:0,avgVol:0,vol:0,sigma:0,k:0,dayVol:.02,desc:'All tracked coins'});
}

/** Decimals used when quantising a price so quotes look like real ticks */
const decimalsFor = v => v >= 10 ? 2 : v >= 1 ? 3 : 4;

function stepAsset(a){
  a.mom = .55 * a.mom + .45 * randn();                       // short-lived momentum
  const rev = -a.k * Math.log(a.price / a.anchor);           // pull back toward anchor
  const r = a.sigma * a.mom * 1.25 + rev;
  const q = Math.pow(10, decimalsFor(a.price));
  const np = a.type === 'index' ? a.price * Math.exp(r) : Math.round(a.price * Math.exp(r) * q) / q;
  a.dir = np > a.price ? 1 : np < a.price ? -1 : 0;
  a.price = np;
  if (np > a.high) a.high = np;
  if (np < a.low)  a.low  = np;
  if (a.type === 'stock')  a.vol += a.avgVol * (.00005 + Math.random() * .00015);
  if (a.type === 'crypto') a.vol *= 1 + (Math.random() - .5) * .0007;
  syncSeries(a);
}
const syncSeries = a => { [a.d1,a.w1,a.m1,a.y1].forEach(s => s[s.length-1] = a.price); };

function updateTMC(){
  const T = A.TMC, cs = LIST.filter(a => a.type === 'crypto');
  const np = cs.reduce((s,a) => s + a.price * a.shares, 0);
  T.dir = np > T.price ? 1 : np < T.price ? -1 : 0;
  T.price = np;
  T.high = Math.max(T.high, np); T.low = Math.min(T.low, np);
  syncSeries(T);
}

const pct   = a => (a.price / a.open - 1) * 100;
const pct7  = a => (a.price / a.w1[0] - 1) * 100;
const chg   = a => a.price - a.open;
const mcap  = a => a.price * a.shares;
const isCryptoLike = a => a.type === 'crypto' || a.sym === 'TMC';

const fmtVal = (a, v) => a.sym === 'TMC' ? '$' + fixed(v / 1e12, 3) + 'T' : a.type === 'index' ? fixed(v, 2) : fmtPrice(v);
const fmtHero = (a, v) => a.type === 'index' ? fmtVal(a, v) : '$' + fmtPrice(v);
const fmtChg = (a, v) => {
  const s = v >= 0 ? '+' : MINUS, x = Math.abs(v);
  return s + (a.sym === 'TMC' ? '$' + fixed(x / 1e9, 0) + 'B' : fmtVal(a, x));
};

/* ======================================================================
   3. APP STATE + PAINTING
   Any element with data-s (symbol) and data-b (binding) is kept in sync
   by paintOne(). This keeps the live updates declarative.
   ====================================================================== */
const state = {
  mode: 'stock',
  sort: {key:'mcap', dir:-1},
  maxVol: {stock:1, crypto:1},
  watch: ['NVDA','BTC','AAPL','ETH','TSLA'],
  fg: {v:50, ready:false},
  t: {agg:0, rank:0, heat:0},
  ready: false,
};

/* ---- glyph helpers ---- */
function glyph(a){
  if (a.type === 'crypto') return `<span class="coin">${icon('c-' + a.sym.toLowerCase())}</span>`;
  if (a.sym === 'TMC')     return `<span class="coin">${icon('c-tmc')}</span>`;
  if (a.type === 'index')  return `<span class="mono">${icon('i-pulse')}</span>`;
  return `<span class="mono">${esc(a.sym.slice(0, a.sym.length > 3 ? 3 : a.sym.length))}</span>`;
}

function sparkSVG(a, cls = ''){
  return `<svg class="spark ${cls}" viewBox="0 0 ${cls === 'lg' ? 96 : 84} ${cls === 'lg' ? 32 : 28}" aria-hidden="true"><path class="draw" pathLength="1" data-b="spark" data-s="${a.sym}" data-w="${cls === 'lg' ? 96 : 84}" data-h="${cls === 'lg' ? 32 : 28}" d=""/></svg>`;
}
function sparkD(a, w, h){
  const s = [];
  for (let i = 0; i <= 96; i += 3) s.push(a.d1[i]);
  let mn = Math.min(...s), mx = Math.max(...s);
  const sp = (mx - mn) || 1;
  return s.map((v, i) => (i ? 'L' : 'M') + (i / (s.length - 1) * w).toFixed(1) + ' ' + (h - 2 - (v - mn) / sp * (h - 4)).toFixed(1)).join('');
}

/* ---- number tween (count transition) ---- */
function tween(el, to, fmt, animate){
  if (!animate || REDUCE || el._cur === undefined){
    cancelAnimationFrame(el._raf); el._cur = to; el.textContent = fmt(to); return;
  }
  const from = el._cur;
  if (from === to) return;
  cancelAnimationFrame(el._raf);
  const t0 = performance.now(), dur = 520;
  const step = t => {
    const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
    el._cur = from + (to - from) * e;
    el.textContent = fmt(p === 1 ? to : el._cur);
    if (p < 1) el._raf = requestAnimationFrame(step); else el._cur = to;
  };
  el._raf = requestAnimationFrame(step);
}

/* ---- flash + tone helpers ---- */
function flash(el, dir){
  el.classList.remove('fl-up','fl-dn');
  void el.offsetWidth;                                  // restart animation
  el.classList.add(dir > 0 ? 'fl-up' : 'fl-dn');
}
function put(el, text, dir, tone){
  if (el.textContent !== text){ el.textContent = text; if (dir && !REDUCE) flash(el, dir); }
  if (tone){ el.classList.toggle('up', tone === 'up'); el.classList.toggle('dn', tone === 'dn'); }
}
const toneOf = v => v >= 0 ? 'up' : 'dn';

/** Heat tile background: neutral → muted green/red, capped for text contrast */
function heatColor(p, a){
  const scale = a.type === 'crypto' ? 6 : 3.5;
  const m = Math.round(8 + clamp(Math.abs(p) / scale, 0, 1) * 38);
  return `color-mix(in srgb, var(${p >= 0 ? '--up' : '--dn'}) ${m}%, var(--bg-3))`;
}

function paintOne(el, fl){
  const a = A[el.dataset.s]; if (!a) return;
  const d = fl ? a.dir : 0;
  switch (el.dataset.b){
    case 'price': put(el, fmtVal(a, a.price), d); break;
    case 'tprice': tween(el, a.price, v => fmtVal(a, v), fl); break;
    case 'hprice': tween(el, a.price, v => fmtHero(a, v), fl); break;
    case 'pct':  { const p = pct(a); put(el, fmtPct(p), d, toneOf(p)); break; }
    case 'pct7': { const p = pct7(a); put(el, fmtPct(p), 0, toneOf(p)); break; }
    case 'chg':  { const c = chg(a); put(el, fmtChg(a, c), 0, toneOf(c)); break; }
    case 'arrow': { const up = pct(a) >= 0; el.classList.toggle('up', up); el.classList.toggle('dn', !up);
                    el.firstElementChild.setAttribute('href', up ? '#i-tri-up' : '#i-tri-dn'); break; }
    case 'spark': { const p = el.ownerSVGElement; p.classList.toggle('up', pct(a) >= 0); p.classList.toggle('dn', pct(a) < 0);
                    el.setAttribute('d', sparkD(a, +el.dataset.w, +el.dataset.h)); break; }
    case 'open': put(el, fmtVal(a, a.open), 0); break;
    case 'high': put(el, fmtVal(a, a.high), 0); break;
    case 'low':  put(el, fmtVal(a, a.low), 0); break;
    case 'vol':  el.textContent = a.type === 'index' ? '\u2014' : a.type === 'crypto' ? fmtCompact(a.vol, '$') : fmtCompact(a.vol); break;
    case 'mcap': el.textContent = a.type === 'index' ? '\u2014' : fmtCompact(mcap(a), '$'); break;
    case 'bar': { const sc = a.type === 'crypto' ? 8 : 4, p = pct(a);
                  el.style.setProperty('--w', (clamp(Math.abs(p) / sc, .03, 1) * 100).toFixed(1) + '%');
                  el.classList.toggle('up', p >= 0); el.classList.toggle('dn', p < 0); break; }
    case 'volbar': el.style.setProperty('--w', (clamp(a.vol / state.maxVol[a.type], .04, 1) * 100).toFixed(1) + '%'); break;
    case 'heat': el.style.backgroundColor = heatColor(pct(a), a); break;
    case 'star': { const on = state.watch.includes(a.sym);
                   el.setAttribute('aria-pressed', on);
                   el.setAttribute('aria-label', (on ? 'Remove ' : 'Add ') + a.name + (on ? ' from' : ' to') + ' watchlist'); break; }
  }
}
function paintNode(root, fl){
  if (root.dataset && root.dataset.s) paintOne(root, fl);
  $$('[data-s]', root).forEach(el => paintOne(el, fl));
}
function paintSym(sym){ $$(`[data-s="${sym}"]`).forEach(el => paintOne(el, true)); }

/** Keyed list reconciliation: reuse nodes, reorder only when needed */
function syncList(parent, items, keyFn, make){
  const map = parent._m || (parent._m = new Map());
  const keep = new Set(items.map(keyFn));
  map.forEach((el, k) => { if (!keep.has(k)){ el.remove(); map.delete(k); } });
  items.forEach((it, i) => {
    const k = keyFn(it); let el = map.get(k);
    if (!el){ el = make(it); map.set(k, el); paintNode(el, false); }
    if (parent.children[i] !== el) parent.insertBefore(el, parent.children[i] || null);
  });
}

/* ======================================================================
   4. HERO CHART  (Canvas 2D, no libraries)
   ====================================================================== */
const RANGE_KEY = {'1D':'d1','1W':'w1','1M':'m1','1Y':'y1'};
const RANGE_LBL = {'1D':'today','1W':'past week','1M':'past month','1Y':'past year'};
const chart = {sym:'SPX', range:'1D', progress:1, hover:null, w:0, h:0, ctx:null, raf:0, theme:null};
const FONT = '"Inter","SF Pro Text","Segoe UI",system-ui,sans-serif';

function readTheme(){
  const cs = getComputedStyle(document.documentElement);
  const g = n => cs.getPropertyValue(n).trim();
  chart.theme = {up:g('--up'), dn:g('--dn'), line:g('--line'), ink:g('--ink'), ink3:g('--ink-3'), bg:g('--bg-1'), tagInk:g('--tag-ink')};
}
function rgba(hex, al){
  const h = hex.replace('#','');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${al})`;
}

function sizeChart(){
  const c = $('#chart'), r = c.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  chart.w = Math.round(r.width); chart.h = Math.round(r.height);
  if (!chart.w) return;
  c.width = chart.w * dpr; c.height = chart.h * dpr;
  chart.ctx = c.getContext('2d');
  if (chart.ctx) chart.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawChart();
}

function timeAt(a, range, f){
  const now = Date.now(), cl = isCryptoLike(a);
  if (range === '1D'){
    if (!cl){
      const m = Math.round(570 + f * 390), h = Math.floor(m / 60), mm = m % 60;
      return ((h + 11) % 12 + 1) + ':' + String(mm).padStart(2,'0') + ' ' + (h >= 12 ? 'PM' : 'AM');
    }
    return new Date(now - (1 - f) * 864e5).toLocaleTimeString('en-US', {hour:'numeric', minute:'2-digit'});
  }
  if (range === '1W') return new Date(now - (1 - f) * 7 * 864e5).toLocaleString('en-US', {weekday:'short', hour:'numeric'});
  if (range === '1M') return new Date(now - (1 - f) * 30 * 864e5).toLocaleDateString('en-US', {month:'short', day:'numeric'});
  return new Date(now - (1 - f) * 365 * 864e5).toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'});
}
function axisTime(a, range, f){
  const now = Date.now(), cl = isCryptoLike(a);
  if (range === '1D') return cl ? new Date(now - (1 - f) * 864e5).toLocaleTimeString('en-US', {hour:'numeric'}) : timeAt(a, range, f);
  if (range === '1W') return new Date(now - (1 - f) * 7 * 864e5).toLocaleDateString('en-US', {weekday:'short'});
  if (range === '1M') return timeAt(a, range, f);
  return new Date(now - (1 - f) * 365 * 864e5).toLocaleDateString('en-US', {month:'short', year:'numeric'});
}

function drawChart(){
  const a = A[chart.sym], ctx = chart.ctx;
  if (!a || !ctx || !chart.w || !chart.theme || !state.ready) return;
  const th = chart.theme, W = chart.w, H = chart.h, p = chart.progress;
  const data = a[RANGE_KEY[chart.range]], n = data.length;
  ctx.clearRect(0, 0, W, H);

  let mn = Math.min(...data), mx = Math.max(...data);
  if (chart.range === '1D'){ mn = Math.min(mn, a.open); mx = Math.max(mx, a.open); }
  const span = (mx - mn) || mx * .002;
  mn -= span * .1; mx += span * .1;

  const padL = 4, padR = W < 480 ? 54 : 66, padT = 12, padB = 26;
  const pw = W - padL - padR, ph = H - padT - padB;
  const X = i => padL + i / (n - 1) * pw;
  const Y = v => padT + (1 - (v - mn) / (mx - mn)) * ph;
  const up = data[n-1] >= data[0], tone = up ? th.up : th.dn;
  const dec = (mx - mn) >= 100 ? 0 : (mx - mn) >= 5 ? 1 : (mx - mn) >= .5 ? 2 : (mx - mn) >= .05 ? 3 : 4;
  const axis = v => a.sym === 'TMC' ? '$' + fixed(v / 1e12, 2) + 'T' : fixed(v, dec);

  // horizontal grid + price axis
  ctx.font = `500 11px ${FONT}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
  ctx.lineWidth = 1;
  for (let k = 0; k <= 4; k++){
    const v = mn + (mx - mn) * k / 4, y = Math.round(Y(v)) + .5;
    ctx.strokeStyle = th.line; ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    ctx.fillStyle = th.ink3; ctx.fillText(axis(v), W - padR + 10, y);
  }
  // time axis
  const ticks = W < 480 ? [0, .5, 1] : [0, .25, .5, .75, 1];
  ctx.textBaseline = 'alphabetic'; ctx.fillStyle = th.ink3;
  ticks.forEach(f => {
    ctx.textAlign = f === 0 ? 'left' : f === 1 ? 'right' : 'center';
    ctx.fillText(axisTime(a, chart.range, f), padL + f * pw, H - 7);
  });

  // opening-price reference (1D)
  if (chart.range === '1D'){
    const y = Math.round(Y(a.open)) + .5;
    ctx.save(); ctx.setLineDash([3, 5]); ctx.strokeStyle = th.ink3; ctx.globalAlpha = .7;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke(); ctx.restore();
  }

  // clip for draw-in
  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, padL + p * pw + 1, H); ctx.clip();
  const g = ctx.createLinearGradient(0, padT, 0, H - padB);
  g.addColorStop(0, rgba(tone, .26)); g.addColorStop(1, rgba(tone, 0));
  ctx.beginPath();
  data.forEach((v, i) => i ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)));
  ctx.lineTo(X(n-1), H - padB); ctx.lineTo(X(0), H - padB); ctx.closePath();
  ctx.fillStyle = g; ctx.fill();
  ctx.beginPath();
  data.forEach((v, i) => i ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)));
  ctx.strokeStyle = tone; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
  ctx.restore();

  // head dot while drawing
  if (p < 1){
    const fi = p * (n - 1), i0 = Math.floor(fi), i1 = Math.min(n - 1, i0 + 1);
    const v = data[i0] + (data[i1] - data[i0]) * (fi - i0);
    ctx.fillStyle = tone; ctx.beginPath(); ctx.arc(padL + p * pw, Y(v), 4, 0, 7); ctx.fill();
  } else {
    // live price tag
    const y = Y(data[n-1]), label = a.sym === 'TMC' ? axis(data[n-1]) : fixed(data[n-1], dec);
    ctx.save(); ctx.setLineDash([2, 4]); ctx.strokeStyle = rgba(tone, .6);
    ctx.beginPath(); ctx.moveTo(X(n-1), y); ctx.lineTo(W - padR + 4, y); ctx.stroke(); ctx.restore();
    ctx.fillStyle = tone;
    const tx = W - padR + 4, tw = padR - 6;
    ctx.beginPath(); (ctx.roundRect ? ctx.roundRect(tx, y - 10, tw, 20, 5) : ctx.rect(tx, y - 10, tw, 20)); ctx.fill();
    ctx.fillStyle = th.tagInk; ctx.font = `650 11px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(label, tx + tw / 2, y + .5);
    ctx.fillStyle = tone; ctx.beginPath(); ctx.arc(X(n-1), y, 3.5, 0, 7); ctx.fill();
  }

  // crosshair
  const tip = $('#tip');
  if (chart.hover != null && p >= 1){
    const i = chart.hover, x = X(i), y = Y(data[i]);
    ctx.save(); ctx.setLineDash([3, 4]); ctx.strokeStyle = th.ink3; ctx.beginPath();
    ctx.moveTo(Math.round(x) + .5, padT); ctx.lineTo(Math.round(x) + .5, H - padB); ctx.stroke(); ctx.restore();
    ctx.fillStyle = th.bg; ctx.strokeStyle = tone; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, 5, 0, 7); ctx.fill(); ctx.stroke();
    const ch = (data[i] / data[0] - 1) * 100;
    tip.innerHTML = `<b>${fmtHero(a, data[i])}</b><span>${timeAt(a, chart.range, i / (n - 1))}</span> <span class="${toneOf(ch)}" style="font-weight:600">${fmtPct(ch)}</span>`;
    tip.style.opacity = 1;
    const tw = tip.offsetWidth;
    tip.style.transform = `translateX(${clamp(x - tw / 2, 4, W - padR - tw)}px)`;
    tip.style.left = '0';
  } else tip.style.opacity = 0;
}

/** Animated draw-in from left to right */
function animateChart(){
  cancelAnimationFrame(chart.raf);
  if (REDUCE){ chart.progress = 1; drawChart(); return; }
  const t0 = performance.now(), dur = 900;
  chart.progress = 0;
  const step = t => {
    const x = Math.min(1, (t - t0) / dur);
    chart.progress = 1 - Math.pow(1 - x, 3);
    drawChart();
    if (x < 1) chart.raf = requestAnimationFrame(step);
  };
  chart.raf = requestAnimationFrame(step);
}

function updateRangeNote(){
  const a = A[chart.sym], d = a[RANGE_KEY[chart.range]];
  const ch = (d[d.length-1] / d[0] - 1) * 100;
  $('#hRange').innerHTML = `<b class="${toneOf(ch)}">${fmtPct(ch)}</b> ${RANGE_LBL[chart.range]}`;
  $('#chart').setAttribute('aria-label',
    `${a.name} ${chart.range} price chart. Last ${fmtVal(a, a.price)}, ${fmtPct(ch)} over the ${RANGE_LBL[chart.range].replace('past ','')} range. Use left and right arrow keys to inspect points.`);
}

function selectAsset(sym, opts = {}){
  const a = A[sym]; if (!a) return;
  chart.sym = sym; chart.hover = null;
  $('#hGlyph').innerHTML = glyph(a);
  $('#hName').textContent = a.name;
  $('#hSub').textContent = a.type === 'index' ? a.desc : `${a.sym}, ${a.group}`;
  $('#volLbl').textContent = a.type === 'crypto' ? 'Volume 24h' : 'Volume';
  $$('#chartPanel [data-s]').forEach(el => { el.dataset.s = sym; el._cur = undefined; });
  paintNode($('#chartPanel'), false);
  $$('.idx-item').forEach(b => { const on = b.dataset.pick === sym; b.classList.toggle('on', on); b.setAttribute('aria-current', on ? 'true' : 'false'); });
  updateRangeNote();
  if (state.ready) animateChart();
  if (opts.scroll){
    const r = $('#chartPanel').getBoundingClientRect();
    if (r.top < 70 || r.top > innerHeight * .5) $('#chartPanel').scrollIntoView({behavior: REDUCE ? 'auto' : 'smooth', block:'start'});
  }
}

/* ======================================================================
   5. MODULES
   ====================================================================== */

/* ---- toast ---- */
let toastT;
function toast(msg){
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2200);
}

/* ---- ticker tape ---- */
function buildTape(){
  const stocks = LIST.filter(a => a.type === 'stock'), cryptos = LIST.filter(a => a.type === 'crypto');
  const order = [A.SPX, A.IXIC, A.DJI, A.TMC];
  for (let i = 0; i < Math.max(stocks.length, cryptos.length); i++){
    if (stocks[i]) order.push(stocks[i]);
    if (cryptos[i]) order.push(cryptos[i]);
  }
  const item = (a, hid) => `<button type="button" class="tp" data-pick="${a.sym}"${hid ? ' tabindex="-1"' : ''}>
      <b>${esc(a.short)}</b><span class="tpx px" data-b="price" data-s="${a.sym}"></span>
      <span class="tpc"><svg class="ic ar" data-b="arrow" data-s="${a.sym}" aria-hidden="true"><use href="#i-tri-up"/></svg><span class="pct" data-b="pct" data-s="${a.sym}"></span></span></button>`;
  $('#tape').innerHTML =
    `<div class="tape-grp">${order.map(a => item(a, false)).join('')}</div>` +
    `<div class="tape-grp" aria-hidden="true">${order.map(a => item(a, true)).join('')}</div>`;
  paintNode($('#tape'), false);
}

/* ---- benchmark list ---- */
function buildIndices(){
  $('#idxList').innerHTML = ['SPX','IXIC','DJI','TMC'].map(s => {
    const a = A[s];
    return `<button type="button" class="idx-item" data-pick="${s}" aria-label="Chart ${esc(a.name)}">
      <span class="t">${esc(a.name)}</span>
      ${sparkSVG(a, 'lg')}
      <span class="d">${esc(a.desc)}</span>
      <span class="lv" data-b="tprice" data-s="${s}"></span>
      <span class="ch"><span class="pct" data-b="pct" data-s="${s}"></span></span>
    </button>`;
  }).join('');
  paintNode($('#idxList'), false);
}

/* ---- movers + most active ---- */
function moverRow(a){
  const li = document.createElement('li');
  li.innerHTML = `<button type="button" class="mv-btn" data-pick="${a.sym}" aria-label="Chart ${esc(a.name)}">
    <i class="mv-bar" data-b="bar" data-s="${a.sym}"></i>
    ${glyph(a)}
    <span class="nm"><b>${a.sym}</b><small>${esc(a.name)}</small></span>
    ${sparkSVG(a)}
    <span class="pp"><span class="px" data-b="price" data-s="${a.sym}"></span><span class="pill" data-b="pct" data-s="${a.sym}"></span></span>
  </button>`;
  return li;
}
function activeRow(a){
  const tr = document.createElement('tr');
  tr.innerHTML = `<td class="l"><button type="button" class="who rowbtn" data-pick="${a.sym}" aria-label="Chart ${esc(a.name)}">${glyph(a)}<span class="nm"><b>${a.sym}</b><small>${esc(a.name)}</small></span></button></td>
    <td><div class="vbar"><i data-b="volbar" data-s="${a.sym}"></i><span data-b="vol" data-s="${a.sym}"></span></div></td>
    <td><div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px"><span class="px" data-b="price" data-s="${a.sym}"></span><span class="pct" data-b="pct" data-s="${a.sym}" style="font-size:12.5px"></span></div></td>`;
  return tr;
}
function renderMovers(){
  const pool = LIST.filter(a => a.type === state.mode);
  state.maxVol[state.mode] = Math.max(...pool.map(a => a.vol));
  const byPct = [...pool].sort((x, y) => pct(y) - pct(x));
  syncList($('#gainList'), byPct.slice(0, 6), a => a.sym, moverRow);
  syncList($('#loseList'), byPct.slice(-6).reverse(), a => a.sym, moverRow);
  syncList($('#actBody'), [...pool].sort((x, y) => y.vol - x.vol).slice(0, 6), a => a.sym, activeRow);
  $$('#actBody [data-b="volbar"]').forEach(el => paintOne(el, false));
}

/* ---- crypto table ---- */
const SORTERS = {name:a => a.name.toLowerCase(), price:a => a.price, pct, w:pct7, mcap, vol:a => a.vol};
function cryptoRow(a){
  const tr = document.createElement('tr');
  tr.innerHTML = `<td class="l rk"></td>
    <td class="l"><button type="button" class="who rowbtn" data-pick="${a.sym}" aria-label="Chart ${esc(a.name)}">${glyph(a)}<span class="nm"><b>${esc(a.name)}</b><small>${a.sym}</small></span></button></td>
    <td><span class="px" data-b="price" data-s="${a.sym}"></span></td>
    <td><span class="pct px" data-b="pct" data-s="${a.sym}"></span></td>
    <td class="hide-sm"><span class="pct" data-b="pct7" data-s="${a.sym}"></span></td>
    <td class="hide-md" data-b="mcap" data-s="${a.sym}"></td>
    <td class="hide-md" data-b="vol" data-s="${a.sym}"></td>
    <td class="hide-sm" style="text-align:right"><span style="display:inline-block;vertical-align:middle">${sparkSVG(a)}</span></td>
    <td><button type="button" class="star" data-star data-b="star" data-s="${a.sym}" aria-pressed="false">${icon('i-star')}</button></td>`;
  return tr;
}
function renderCrypto(){
  const {key, dir} = state.sort, f = SORTERS[key];
  const rows = LIST.filter(a => a.type === 'crypto').sort((x, y) => {
    const u = f(x), v = f(y); return (u > v ? 1 : u < v ? -1 : 0) * dir;
  });
  syncList($('#crBody'), rows, a => a.sym, cryptoRow);
  $$('#crBody tr').forEach((tr, i) => { tr.firstElementChild.textContent = i + 1; });
}

/* ---- aggregates, gauge, share bar ---- */
function buildGauge(){
  const cx = 150, cy = 150, r = 118, g = .8;
  const pt = (v, rr) => { const t = Math.PI * (1 - v / 100); return [cx + rr * Math.cos(t), cy - rr * Math.sin(t)]; };
  const zones = [[0,25,'--dn',1],[25,45,'--dn',.5],[45,55,'--ink-3',.7],[55,75,'--up',.5],[75,100,'--up',1]];
  const arcs = zones.map(([a, b, c, o]) => {
    const [x0, y0] = pt(a + (a ? g : 0), r), [x1, y1] = pt(b - (b < 100 ? g : 0), r);
    return `<path class="arc" d="M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 0 1 ${x1.toFixed(1)} ${y1.toFixed(1)}" stroke="var(${c})" opacity="${o}"/>`;
  }).join('');
  const ticks = [0,25,50,75,100].map(v => { const [x0,y0] = pt(v, r + 12), [x1,y1] = pt(v, r + 18);
    return `<path d="M${x0.toFixed(1)} ${y0.toFixed(1)}L${x1.toFixed(1)} ${y1.toFixed(1)}" stroke="var(--ink-3)" stroke-width="1.5" stroke-linecap="round"/>`; }).join('');
  $('#gauge').innerHTML = `<svg viewBox="0 0 300 172" role="img" aria-label="Fear and greed gauge">
    ${arcs}${ticks}
    <text x="30" y="168" fill="var(--ink-3)" font-size="11" font-weight="500" text-anchor="start">Extreme fear</text>
    <text x="270" y="168" fill="var(--ink-3)" font-size="11" font-weight="500" text-anchor="end">Extreme greed</text>
    <g class="needle" id="needle" style="transform:rotate(-90deg)">
      <path d="M150 150L150 50" stroke="var(--ink)" stroke-width="2.6" stroke-linecap="round"/>
      <circle cx="150" cy="150" r="8" fill="var(--bg-1)" stroke="var(--ink)" stroke-width="2.6"/>
    </g></svg>`;
}
const fgLabel = v => v < 25 ? 'Extreme fear' : v < 45 ? 'Fear' : v < 55 ? 'Neutral' : v < 75 ? 'Greed' : 'Extreme greed';

function computeSentiment(){
  const cs = LIST.filter(a => a.type === 'crypto'), T = A.TMC;
  const avg = cs.reduce((s, a) => s + pct(a), 0) / cs.length;
  const abs = cs.reduce((s, a) => s + Math.abs(pct(a)), 0) / cs.length;
  const breadth = cs.filter(a => pct(a) > 0).length / cs.length * 100;
  const dom = mcap(A.BTC) / T.price * 100;
  const vol = cs.reduce((s, a) => s + a.vol, 0), base = cs.reduce((s, a) => s + a.avgVol, 0);
  const m = {
    Momentum: clamp(50 + avg * 8, 0, 100),
    Breadth: breadth,
    Volatility: clamp(100 - abs * 14, 0, 100),
    Dominance: clamp(100 - (dom - 35) * 2.2, 0, 100),
    Volume: clamp(50 + (vol / base - 1) * 220, 0, 100),
  };
  const score = m.Momentum * .3 + m.Breadth * .2 + m.Volatility * .2 + m.Dominance * .15 + m.Volume * .15;
  return {m, score, dom, vol};
}

function updateAggregates(){
  const S = computeSentiment(), T = A.TMC;
  tween($('#kCap'), T.price, v => '$' + fixed(v / 1e12, 3) + 'T', true);
  tween($('#kVol'), S.vol, v => fmtCompact(v, '$'), true);
  tween($('#kDom'), S.dom, v => fixed(v, 1) + '%', true);

  // fear & greed
  state.fg.v += (S.score - state.fg.v) * (state.fg.ready ? .2 : 1);
  const v = Math.round(state.fg.v);
  tween($('#fgVal'), v, x => String(Math.round(x)), state.fg.ready);
  $('#fgLbl').textContent = fgLabel(v);
  $('#needle').style.transform = `rotate(${(state.fg.v / 100) * 180 - 90}deg)`;
  const ml = $('#meters');
  if (!ml.children.length) ml.innerHTML = Object.keys(S.m).map(k => `<li><span>${k}</span><i><b data-k="${k}"></b></i><em data-e="${k}">0</em></li>`).join('');
  Object.entries(S.m).forEach(([k, val]) => {
    $(`[data-k="${k}"]`, ml).style.setProperty('--w', val.toFixed(0) + '%');
    $(`[data-e="${k}"]`, ml).textContent = Math.round(val);
  });
  if (!state.fg.ready){
    state.fg.ready = true;
    const h = [['Yesterday', 6], ['Last week', 11], ['Last month', 16]];
    $('#fgHist').innerHTML = h.map(([l, s]) => { const x = Math.round(clamp(state.fg.v + randn() * s, 4, 96));
      return `<div><dt>${l}</dt><dd>${x} <span class="muted" style="font-weight:500">${fgLabel(x)}</span></dd></div>`; }).join('');
  }
}

function updateShare(){
  const cs = LIST.filter(a => a.type === 'crypto').sort((x, y) => mcap(y) - mcap(x)), tot = A.TMC.price;
  const top = cs.slice(0, 5), rest = 100 - top.reduce((s, a) => s + mcap(a) / tot * 100, 0);
  const segs = top.map((a, i) => ({n:a.sym, p:mcap(a) / tot * 100, o:1 - i * .17})).concat({n:'Others', p:rest, o:.3});
  const bar = $('#shareBar'), leg = $('#shareLeg');
  if (bar.children.length !== segs.length){
    bar.innerHTML = segs.map(() => '<i></i>').join('');
    leg.innerHTML = segs.map(() => '<li><i></i><span></span><b></b></li>').join('');
  }
  segs.forEach((s, i) => {
    const b = bar.children[i]; b.style.setProperty('--w', s.p.toFixed(2) + '%'); b.style.setProperty('--o', s.o);
    const li = leg.children[i]; li.firstChild.style.setProperty('--o', s.o);
    li.children[1].textContent = s.n; li.children[2].textContent = fixed(s.p, 1) + '%';
  });
  bar.setAttribute('aria-label', 'Share of market cap: ' + segs.map(s => `${s.n} ${fixed(s.p, 1)} percent`).join(', '));
}

/* ---- heatmap (squarified treemap, sectors then companies) ---- */
function squarify(items, x, y, w, h){
  if (!items.length || w <= 0 || h <= 0) return [];
  const total = items.reduce((s, i) => s + i.value, 0), k = w * h / total;
  const nodes = items.map(i => ({item:i, area:i.value * k}));
  const out = []; let rect = {x, y, w, h}, row = [];
  const worst = (r, side) => { const s = r.reduce((q, n) => q + n.area, 0), mx = Math.max(...r.map(n => n.area)), mn = Math.min(...r.map(n => n.area));
    return Math.max(side * side * mx / (s * s), s * s / (side * side * mn)); };
  const place = r => {
    const s = r.reduce((q, n) => q + n.area, 0);
    if (rect.w >= rect.h){
      const cw = s / rect.h; let cy = rect.y;
      r.forEach(n => { const nh = n.area / cw; out.push({item:n.item, x:rect.x, y:cy, w:cw, h:nh}); cy += nh; });
      rect = {x:rect.x + cw, y:rect.y, w:rect.w - cw, h:rect.h};
    } else {
      const rh = s / rect.w; let cx = rect.x;
      r.forEach(n => { const nw = n.area / rh; out.push({item:n.item, x:cx, y:rect.y, w:nw, h:rh}); cx += nw; });
      rect = {x:rect.x, y:rect.y + rh, w:rect.w, h:rect.h - rh};
    }
  };
  nodes.forEach(n => {
    const side = Math.min(rect.w, rect.h);
    if (!row.length || worst(row.concat(n), side) <= worst(row, side)) row.push(n);
    else { place(row); row = [n]; }
  });
  if (row.length) place(row);
  return out;
}

const heat = {tiles:new Map(), labels:new Map(), mode:null};
function layoutHeat(){
  const el = $('#heat'), W = el.clientWidth, H = el.clientHeight;
  if (!W || !H) return;
  if (heat.mode !== state.mode){ el.replaceChildren(); heat.tiles.clear(); heat.labels.clear(); heat.mode = state.mode; }
  const pool = LIST.filter(a => a.type === state.mode), groups = {};
  pool.forEach(a => (groups[a.group] || (groups[a.group] = {key:a.group, value:0, kids:[]})).kids.push({a, value:mcap(a)}));
  const secs = Object.values(groups).map(g => (g.value = g.kids.reduce((s, k) => s + k.value, 0), g)).sort((x, y) => y.value - x.value);
  const seen = new Set();
  squarify(secs, 0, 0, W, H).forEach(sr => {
    const g = sr.item, gap = 2;
    const showLbl = sr.h > 52 && sr.w > 72, lh = showLbl ? 20 : 0;
    let lab = heat.labels.get(g.key);
    if (!lab){ lab = document.createElement('div'); lab.className = 'hg'; lab.textContent = g.key; el.appendChild(lab); heat.labels.set(g.key, lab); }
    Object.assign(lab.style, {left:sr.x + gap + 'px', top:sr.y + gap + 'px', width:Math.max(0, sr.w - gap * 2) + 'px', display:showLbl ? '' : 'none'});
    const inner = {x:sr.x + gap, y:sr.y + gap + lh, w:sr.w - gap * 2, h:sr.h - gap * 2 - lh};
    const kids = g.kids.sort((x, y) => y.value - x.value);
    squarify(kids, inner.x, inner.y, inner.w, inner.h).forEach(kr => {
      const a = kr.item.a; seen.add(a.sym);
      let t = heat.tiles.get(a.sym);
      if (!t){
        t = document.createElement('button'); t.type = 'button'; t.className = 'tile'; t.dataset.pick = a.sym;
        t.dataset.b = 'heat'; t.dataset.s = a.sym; t.setAttribute('aria-label', a.name);
        t.innerHTML = `<b>${a.sym}</b><span class="pct" data-b="pct" data-s="${a.sym}"></span>`;
        el.appendChild(t); heat.tiles.set(a.sym, t); paintNode(t, false);
      }
      const w = Math.max(0, kr.w - 2), h = Math.max(0, kr.h - 2), m = Math.min(w, h);
      Object.assign(t.style, {left:kr.x + 1 + 'px', top:kr.y + 1 + 'px', width:w + 'px', height:h + 'px', fontSize:clamp(m / 4.4, 10, 24) + 'px'});
      t.classList.toggle('xs', w < 34 || h < 26);
      t.classList.toggle('s', h < 46 && !(w < 34 || h < 26));
    });
  });
}

/* ---- watchlist ---- */
function watchRow(sym){
  const a = A[sym], li = document.createElement('li');
  li.className = 'wl-row';
  li.innerHTML = `<button type="button" class="wl-main" data-pick="${sym}" aria-label="Chart ${esc(a.name)}">
      ${glyph(a)}<span class="nm"><b>${sym}</b><small>${esc(a.name)}</small></span>${sparkSVG(a)}
      <span class="pp"><span class="px" data-b="price" data-s="${sym}"></span><span class="pill" data-b="pct" data-s="${sym}"></span></span>
    </button>
    <button type="button" class="wl-rm" data-star="${sym}" aria-label="Remove ${esc(a.name)} from watchlist">${icon('i-x')}</button>`;
  return li;
}
function renderWatch(){
  syncList($('#wlList'), state.watch, s => s, watchRow);
  $('#wlEmpty').hidden = state.watch.length > 0;
  $('#wlCount').textContent = state.watch.length;
  $$('[data-b="star"]').forEach(el => paintOne(el, false));
}
function toggleWatch(sym){
  const a = A[sym]; if (!a) return;
  const i = state.watch.indexOf(sym);
  if (i >= 0){ state.watch.splice(i, 1); toast(`Removed ${a.sym} from watchlist`); }
  else { state.watch.push(sym); toast(`Added ${a.sym} to watchlist`); }
  renderWatch();
}

/* ---- searchable combobox (nav search + watchlist add) ---- */
function attachSearch(input, list, {source, onPick, tag}){
  let items = [], active = -1;
  const row = (a, i) => `<li role="option" id="${list.id}-${i}" data-i="${i}" aria-selected="${i === active}">${glyph(a)}<span class="rs"><b>${a.type === 'index' ? esc(a.short) : a.sym}</b> <span class="nm">${esc(a.name)}</span></span><em>${tag(a)}</em></li>`;
  function render(){
    items = source(input.value);
    list.innerHTML = items.length ? items.map(row).join('')
      : `<li class="empty" role="option" aria-selected="false">No match for \u201c${esc(input.value.trim())}\u201d. Try a ticker such as NVDA or BTC.</li>`;
  }
  const open  = () => { active = -1; render(); list.hidden = false; input.setAttribute('aria-expanded', 'true'); };
  const close = () => { list.hidden = true; active = -1; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); };
  const mark  = () => { $$('li', list).forEach((li, i) => li.setAttribute('aria-selected', i === active));
    if (active >= 0) input.setAttribute('aria-activedescendant', `${list.id}-${active}`);
    const cur = $(`li[data-i="${active}"]`, list); if (cur) cur.scrollIntoView({block:'nearest'}); };
  const pick  = a => { onPick(a); input.value = ''; close(); };
  input.addEventListener('input', open);
  input.addEventListener('focus', open);
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown'){ e.preventDefault(); if (list.hidden) open(); if (items.length){ active = (active + 1) % items.length; mark(); } }
    else if (e.key === 'ArrowUp'){ e.preventDefault(); if (items.length){ active = (active - 1 + items.length) % items.length; mark(); } }
    else if (e.key === 'Enter'){ if (items.length){ e.preventDefault(); pick(items[active >= 0 ? active : 0]); input.blur(); } }
    else if (e.key === 'Escape'){ close(); input.blur(); }
  });
  list.addEventListener('mousedown', e => { const li = e.target.closest('li[data-i]'); if (li){ e.preventDefault(); pick(items[+li.dataset.i]); input.blur(); } });
  document.addEventListener('click', e => { if (!input.parentElement.contains(e.target)) close(); });
}
function searchSource(excludeWatched){
  return q => {
    const s = q.trim().toLowerCase();
    let pool = LIST.filter(a => !excludeWatched || (a.type !== 'index' && !state.watch.includes(a.sym)));
    if (!s) return pool.filter(a => excludeWatched ? true : (a.type === state.mode || a.type === 'index')).sort((x, y) => mcap(y) - mcap(x)).slice(0, 6);
    const rank = a => a.sym.toLowerCase().startsWith(s) ? 0 : a.name.toLowerCase().startsWith(s) ? 1 : 2;
    return pool.filter(a => a.sym.toLowerCase().includes(s) || a.name.toLowerCase().includes(s) || a.short.toLowerCase().includes(s))
               .sort((x, y) => rank(x) - rank(y)).slice(0, 8);
  };
}
const typeTag = a => a.sym === 'TMC' || a.type === 'index' ? 'Index' : a.type === 'crypto' ? 'Crypto' : 'Stock';

/* ---- mode (stocks / crypto) ---- */
function setMode(m){
  if (m === state.mode) return;
  state.mode = m;
  document.body.dataset.mode = m;
  $$('.mode button').forEach(b => b.setAttribute('aria-pressed', b.dataset.mode === m));
  applyModeCopy();
  renderMovers();
  layoutHeat();
  const cur = A[chart.sym];
  if (m === 'crypto' && !isCryptoLike(cur)) selectAsset('BTC');
  else if (m === 'stock' && isCryptoLike(cur)) selectAsset('SPX');
}
function applyModeCopy(){
  const c = state.mode === 'crypto';
  $('#mvSub').textContent = c ? 'Largest moves among 12 digital assets over the last 24 hours.' : 'Largest moves among 15 US large caps since the open.';
  $('#actUnit').textContent = c ? 'USD volume, 24h' : 'Shares traded';
  $('#heatT').textContent = c ? 'Digital assets by category' : 'US large caps by sector';
  $('#legLo').textContent = c ? '-6%' : '-3.5%';
  $('#legHi').textContent = c ? '+6%' : '+3.5%';
}

/* ---- theme: toggled by site.js, which fires this event ---- */
window.addEventListener('kryptooo:theme', () => { readTheme(); drawChart(); });

/* ======================================================================
   6. EVENTS
   ====================================================================== */
function bindEvents(){
  document.addEventListener('click', e => {
    const noop = e.target.closest('[data-noop]'); if (noop){ e.preventDefault(); return; }
    const star = e.target.closest('[data-star]');
    if (star){ toggleWatch(star.dataset.star || star.dataset.s); return; }
    const pick = e.target.closest('[data-pick]');
    if (pick){ selectAsset(pick.dataset.pick, {scroll:true}); return; }
    const sort = e.target.closest('[data-sort]');
    if (sort){
      const k = sort.dataset.sort;
      state.sort = {key:k, dir: state.sort.key === k ? -state.sort.dir : (k === 'name' ? 1 : -1)};
      $$('#crTable th[aria-sort]').forEach(th => { const b = $('button', th);
        th.setAttribute('aria-sort', b.dataset.sort === k ? (state.sort.dir > 0 ? 'ascending' : 'descending') : 'none'); });
      renderCrypto(); return;
    }
    const rg = e.target.closest('[data-range]');
    if (rg){
      chart.range = rg.dataset.range; chart.hover = null;
      $$('#ranges button').forEach(b => b.setAttribute('aria-pressed', b === rg));
      updateRangeNote(); animateChart(); return;
    }
    const md = e.target.closest('button[data-mode]');
    if (md){ setMode(md.dataset.mode); return; }
  });

  $('#wlJump').addEventListener('click', () => {
    $('#watch').scrollIntoView({behavior: REDUCE ? 'auto' : 'smooth', block:'center'});
    setTimeout(() => $('#wlq').focus({preventScroll:true}), REDUCE ? 0 : 450);
  });

  // "/" focuses search (unless typing somewhere)
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName) && !e.metaKey && !e.ctrlKey){ e.preventDefault(); $('#q').focus(); }
  });

  // chart interaction: pointer scrub + keyboard
  const cv = $('#chart');
  const idxFromX = clientX => {
    const r = cv.getBoundingClientRect(), n = A[chart.sym][RANGE_KEY[chart.range]].length;
    const padL = 4, padR = chart.w < 480 ? 54 : 66, pw = chart.w - padL - padR;
    return clamp(Math.round((clientX - r.left - padL) / pw * (n - 1)), 0, n - 1);
  };
  cv.addEventListener('pointermove', e => { chart.hover = idxFromX(e.clientX); drawChart(); });
  cv.addEventListener('pointerleave', () => { chart.hover = null; drawChart(); });
  cv.addEventListener('pointercancel', () => { chart.hover = null; drawChart(); });
  cv.addEventListener('keydown', e => {
    const n = A[chart.sym][RANGE_KEY[chart.range]].length, step = e.shiftKey ? 10 : 1;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight'){
      e.preventDefault();
      const cur = chart.hover == null ? n - 1 : chart.hover;
      chart.hover = clamp(cur + (e.key === 'ArrowLeft' ? -step : step), 0, n - 1); drawChart();
    } else if (e.key === 'Home'){ e.preventDefault(); chart.hover = 0; drawChart(); }
    else if (e.key === 'End'){ e.preventDefault(); chart.hover = n - 1; drawChart(); }
    else if (e.key === 'Escape'){ chart.hover = null; drawChart(); }
  });
  cv.addEventListener('blur', () => { chart.hover = null; drawChart(); });

  // finish sparkline draw-in, then drop the dash styling so live updates render fully
  document.addEventListener('animationend', e => { if (e.target.classList && e.target.classList.contains('draw') && e.animationName === 'dash') e.target.classList.remove('draw'); });

  new ResizeObserver(sizeChart).observe($('#cwrap'));
  new ResizeObserver(() => state.ready && layoutHeat()).observe($('#heat'));

  attachSearch($('#q'), $('#qList'), {source:searchSource(false), tag:typeTag,
    onPick:a => { selectAsset(a.sym, {scroll:true}); $('#q').blur(); }});
  attachSearch($('#wlq'), $('#wlResults'), {source:searchSource(true), tag:typeTag,
    onPick:a => { if (!state.watch.includes(a.sym)) toggleWatch(a.sym); }});
}

/* ======================================================================
   7. LOOP + BOOT
   ====================================================================== */
function loop(){
  if (!state.ready) return;
  const now = performance.now(), due = [];
  for (const a of LIST){
    if (a.agg || now < a.nextAt) continue;
    stepAsset(a); a.nextAt = now + 1000 + Math.random() * 2000; due.push(a);
  }
  if (!due.length) return;
  if (due.some(a => a.type === 'crypto')){ updateTMC(); due.push(A.TMC); }
  due.forEach(a => paintSym(a.sym));
  if (due.includes(A[chart.sym])){ if (chart.progress >= 1) drawChart(); updateRangeNote(); }
  if (now - state.t.agg > 1000){ state.t.agg = now; updateAggregates(); }
  if (now - state.t.rank > 2500){ state.t.rank = now; renderMovers(); renderCrypto(); updateShare(); }
  if (now - state.t.heat > 9000){ state.t.heat = now; layoutHeat(); }
}

function tickClock(){
  $('#clock').textContent = new Date().toLocaleTimeString('en-US', {hour:'numeric', minute:'2-digit', second:'2-digit', timeZoneName:'short'});
}

function showSkeletons(){
  $$('[data-skel]').forEach(el => {
    el.innerHTML = Array.from({length:+el.dataset.skel}, () => '<div class="sk-row"><span class="sk"></span><span class="sk"></span><span class="sk"></span></div>').join('');
  });
}

function hydrate(){
  buildTape(); buildIndices(); buildGauge();
  applyModeCopy();
  renderMovers(); renderCrypto(); renderWatch();
  updateAggregates(); updateShare();
  $$('[data-skel],[data-skel-chart],[data-skel-heat]').forEach(el => el.remove());
  document.body.classList.remove('is-loading');
  state.ready = true;
  layoutHeat();
  selectAsset('SPX');
  sizeChart();
  state.t = {agg:performance.now(), rank:performance.now(), heat:performance.now()};
}

function boot(){
  buildAssets();
  readTheme();
  showSkeletons();
  tickClock(); setInterval(tickClock, 1000);
  bindEvents();
  // static pre-paint of hero header values while skeletons show
  const first = A.SPX;
  $('#hGlyph').innerHTML = glyph(first);
  setTimeout(hydrate, REDUCE ? 0 : 1000);
  setInterval(loop, 250);
}
boot();
})();
